package com.untrustworthypillars.simplefoodlogger;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Class for the Fragment of the home page
 *
 */

public class HomePageFragment extends Fragment {

    private static final String DIALOG_DATE = "DialogDate";

    private static final int REQUEST_DATE = 0;
    private static final int REQUEST_ADD_LOG = 1;
    private static final int REQUEST_EDIT_LOG = 2;

    private LogManager mLogManager;
    private RecyclerView mLogRecyclerView;
    private LogAdapter mLogAdapter;
    private FloatingActionButton mLogMealFAB;
    private Button mDateButton;
    private ImageButton mPreviousDay;
    private ImageButton mNextDay;
    private TextView mCaloriesText;
    private TextView mProteinText;
    private TextView mCarbsText;
    private TextView mFatText;
    private ProgressBar mCaloriesProgress;
    private ProgressBar mProteinProgress;
    private ProgressBar mCarbsProgress;
    private ProgressBar mFatProgress;

    private Date mSelectedDay; //TODO Probably should some global public app variable in order to track which day is selected
    private String mCaloriesGoal = "2500";  //TODO All of these should be local preferences
    private String mProteinGoal = "200";
    private String mCarbsGoal = "300";
    private String mFatGoal = "90";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home_page, container, false);

        mSelectedDay = new Date();

        mLogManager = LogManager.get(getContext());

        mLogRecyclerView = (RecyclerView) v.findViewById(R.id.log_recycler_view);
        mLogRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));



        /**Floating action button implementation - it basically just opens Food List tab, also changing
         * the selected Tab via activity's method setTab(int) */
        mLogMealFAB = (FloatingActionButton) v.findViewById(R.id.floating_button_logmeal);
        mLogMealFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start
                Intent intent = AddLogActivity.newIntent(getActivity(), mSelectedDay);
                startActivityForResult(intent, REQUEST_ADD_LOG);
                //end

                //FragmentManager fm = getActivity().getSupportFragmentManager();
                //fm.beginTransaction().replace(R.id.fragment_container, new FoodListFragment()).commit();

                //LoggerActivity act = (LoggerActivity) getActivity();
                //act.setTab(act.TAB_FOODS);
            }
        });

        mDateButton = (Button) v.findViewById(R.id.date_picker_button);
        mDateButton.setText(Calculations.dateDisplayString(mSelectedDay));
        mDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                DatePickerDialog dialog = DatePickerDialog.newInstance(mSelectedDay);
                dialog.setTargetFragment(HomePageFragment.this, REQUEST_DATE);
                dialog.show(fm, DIALOG_DATE);
            }
        });

        mPreviousDay = (ImageButton) v.findViewById(R.id.image_button_previousday);
        mPreviousDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(mSelectedDay);
                cal.add(Calendar.DATE, -1);
                mSelectedDay = cal.getTime();
                mDateButton.setText(Calculations.dateDisplayString(mSelectedDay));
                updateUI();
            }
        });

        mNextDay = (ImageButton) v.findViewById(R.id.image_button_nextday);
        mNextDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(mSelectedDay);
                cal.add(Calendar.DATE, +1);
                mSelectedDay = cal.getTime();
                mDateButton.setText(Calculations.dateDisplayString(mSelectedDay));
                updateUI();
            }
        });

        mCaloriesText = (TextView) v.findViewById(R.id.textview_calories);
        mProteinText = (TextView) v.findViewById(R.id.textview_protein);
        mCarbsText = (TextView) v.findViewById(R.id.textview_carbs);
        mFatText = (TextView) v.findViewById(R.id.textview_fat);
        mCaloriesProgress = (ProgressBar) v.findViewById(R.id.progress_bar_calories);
        mCaloriesProgress.setMax(Integer.parseInt(mCaloriesGoal));
        mProteinProgress = (ProgressBar) v.findViewById(R.id.progress_bar_protein);
        mProteinProgress.setMax(Integer.parseInt(mProteinGoal));
        mCarbsProgress = (ProgressBar) v.findViewById(R.id.progress_bar_carbs);
        mCarbsProgress.setMax(Integer.parseInt(mCarbsGoal));
        mFatProgress = (ProgressBar) v.findViewById(R.id.progress_bar_fat);
        mFatProgress.setMax(Integer.parseInt(mFatGoal));

        updateUI();

        return v;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (requestCode == REQUEST_DATE) {
            mSelectedDay = (Date) data.getSerializableExtra(DatePickerDialog.EXTRA_DATE);
            mDateButton.setText(Calculations.dateDisplayString(mSelectedDay));
            updateUI();
        }
        if (requestCode == REQUEST_ADD_LOG) {
            updateUI();
            //Toast.makeText(getActivity(), "Returned from another activity", Toast.LENGTH_SHORT).show();
        }
        if (requestCode == REQUEST_EDIT_LOG) {
            updateUI();
        }
    }

    /**Method used to update UI elements of home page after something changes */
    private void updateUI() {
        List<Log> logs = mLogManager.getLogsDay(mSelectedDay);
        mLogAdapter = new LogAdapter(logs);
        mLogRecyclerView.setAdapter(mLogAdapter);

        Float[] result = Calculations.calculateKcalAndMacros(logs);
        mCaloriesText.setText("Calories: " + result[0].intValue() + " / " + mCaloriesGoal);
        mCaloriesProgress.setProgress(result[0].intValue());
        mProteinText.setText("Protein: " + result[1].intValue() + "/" + mProteinGoal + "g");
        mProteinProgress.setProgress(result[1].intValue());
        mCarbsText.setText("Carbs: " + result[2].intValue() + "/" + mCarbsGoal + "g");
        mCarbsProgress.setProgress(result[2].intValue());
        mFatText.setText("Fat: " + result[3].intValue() + "/" + mFatGoal + "g");
        mFatProgress.setProgress(result[3].intValue());
    }

    private class LogHolder extends RecyclerView.ViewHolder implements View.OnLongClickListener {
        private TextView mFoodTitleTextView;
        private TextView mFoodCalories;
        private TextView mFoodProtein;
        private TextView mFoodCarbs;
        private TextView mFoodFat;
        private UUID mLogId;

        public LogHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_log, parent, false));
            itemView.setOnLongClickListener(this);

            mFoodTitleTextView = (TextView) itemView.findViewById(R.id.list_item_log_name);
            mFoodCalories = (TextView) itemView.findViewById(R.id.list_item_log_calories);
            mFoodProtein = (TextView) itemView.findViewById(R.id.list_item_log_protein);
            mFoodCarbs = (TextView) itemView.findViewById(R.id.list_item_log_carbs);
            mFoodFat = (TextView) itemView.findViewById(R.id.list_item_log_fat);
        }

        //TODO make these strings properly as suggested
        public void bind(Log log) {
            mLogId = log.getLogId();
            mFoodTitleTextView.setText(log.getFood() + ", " + log.getSize().intValue() + "g");
            mFoodCalories.setText(log.getKcal().intValue() + " kcal");
            mFoodProtein.setText("Protein: " + String.format("%.1f", log.getProtein()) + "g");
            mFoodCarbs.setText("Carbs: " + String.format("%.1f", log.getCarbs()) + "g");
            mFoodFat.setText("Fat: " + String.format("%.1f", log.getFat()) + "g");
        }

        public boolean onLongClick(View v) {
            FragmentManager fm = getFragmentManager();
            EditLogDialog dialog = EditLogDialog.newInstance(mLogId);
            dialog.setTargetFragment(HomePageFragment.this, REQUEST_EDIT_LOG);
            dialog.show(fm, "OnLongClick");
            return true;
        }
    }

    private class LogAdapter extends RecyclerView.Adapter<LogHolder> {

        private List<Log> mSelectedDayLogs;

        public LogAdapter(List<Log> logs) {
            mSelectedDayLogs = logs;
        }

        @Override
        public LogHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());

            return new LogHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(LogHolder holder, int position) {
        holder.bind(mSelectedDayLogs.get(position));
        }

        @Override
        public int getItemCount() {
            return mSelectedDayLogs.size();
        }
    }

}

//TODO make this whole fragment layout a scrollpane

